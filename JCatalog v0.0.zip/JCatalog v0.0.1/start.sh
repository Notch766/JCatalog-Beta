#! /bin/bash

java -jar JCatalog.jar
