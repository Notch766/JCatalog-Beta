Welcome to JCatalog v0.0.1

If There is any Java Error, please install the latest Java version (Java 24)

Download Java 24 by Oracle here: https://download.oracle.com/java/24/latest/jdk-24_windows-x64_bin.exe

How to execute JCatalog for Windows:

	Way 1: Double click JCatalog.jar 
	Way 2: Open CMD in the Folder and Enter java -jar JCatalog.jar
	Way 3: Double Click start.bat

How to Execute for Linux:

	Way 1: Open Terminal in Folder and Enter java -jar JCatalog.jar
	Way 2: Double Click start.sh

WARNING! DO NOT DELETE data.txt!!! THIS WILL RUIN THE PROGRAM!!!
